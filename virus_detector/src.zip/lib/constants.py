CONST = {}
CONST['TEST_FILE'] = 'test.csv'
CONST['TRAINING_FILE'] = 'train.csv'
CONST['isTest'] = True
CONST['isTrain'] = False
CONST['HEADERS'] = ["Algorithm", "Precision", "Recall", "f1-Score", "Accuracy"]
CONST['TITLE'] = 'Implementation of FrameWork for Malware analysis in Android.'